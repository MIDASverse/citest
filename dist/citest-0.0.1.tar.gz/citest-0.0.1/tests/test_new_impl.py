import src.citest.test as test
from src.citest.data import v4_dgp, MAR1
from src.citest.classifier import RandomForest
from src.citest.imputer import *

import numpy as np

B = 20
ps = [np.nan for _ in range(B)]

for b in range(B):
    print(b)
    test_data = MAR1(1000, ci=False)

    test1 = test.RLTest(
        test_data,
        imputer=IterativeImputer,
        classifier=RandomForest,
        n_folds=10,
        repetitions=10,
        classifier_args={"n_estimators": 5},
        imputer_args={"max_iter": 30},
    )

    test1.run()
    ps[b] = test1.results["p"]

print(np.mean(np.array(ps) < 0.05))
