import pandas as pd

from sklearn.experimental import enable_iterative_imputer  # noqa
from sklearn.impute import IterativeImputer as skII

from .data import Dataset


class Imputer:
    """Base model for imputing missing data

    This class contains the core structure for imputing and accessing
    missing data.

    Plauibly, any imputer can be used with this API, so long as the `completed`
    attribute is set either in the intialization or by a custom _complete method
    call.

    Attributes:
        dataset: A Dataset object
        model: A fitted imputation model
        completed: A numpy array with all missing data imputed

    """

    def __init__(
        self,
        dataset: Dataset,
    ):
        self.dataset = dataset
        self.model = None
        self.completed = None

    def _complete(self, **kwargs):
        """Hidden completion method

        This method should be implemented in the subclass to complete
        the missing data
        """
        # Empty generic method -- used to impute data
        pass

    def get_complete(self, **kwargs) -> pd.DataFrame:
        """Get imputed data

        This method will return the imputed data, if it has already
        been imputed, otherwise it will call the hidden completion
        method first.

        """
        # Return imputed data once set
        if self.completed is None:
            self._complete(**kwargs)
        return self.completed


class CompleteImputer(Imputer):
    """Impute missing data with complete cases

    This imputer fills in missing data with the full data. This is
    used for simulation purposes, and cannot be used for real data tests.

    """

    def __init__(self, dataset=None):
        super().__init__(dataset)
        self.completed = self.dataset.full_data


class NullImputer(Imputer):
    """Impute missing data with zeros

    This imputer fills in missing data with zeros. This is used for
    simulation testing, and likely will not work for real data tests.

    """

    def __init__(self, dataset=None):
        super().__init__(dataset)
        self.completed = self.dataset.miss_data.fillna(0)


class IterativeImputer(Imputer):
    """Impute missing data with an iterative imputer

    This imputer uses the sklearn IterativeImputer to fill in missing data.

    This imputer can be used with real data. Additional arguments may be
    passed to the imputation model through the imputer_args parameter in
    the test module.

    """

    def __init__(self, dataset=None):
        super().__init__(dataset)

    def _complete(self, **kwargs):
        imputer = skII(**kwargs)
        imputer.set_output(transform="pandas")
        self.completed = imputer.fit_transform(self.dataset.miss_data)
        self.model = imputer
